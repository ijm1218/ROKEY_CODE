#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState
from std_msgs.msg import Float64MultiArray
import numpy as np
import matplotlib.pyplot as plt
import csv


class JointPIDController(Node):
    def __init__(self):
        super().__init__('joint_pid_controller')

        # 조인트 수 (Doosan 6 DOF)
        self.num_joints = 6

        # 목표 위치 (radian)
        self.target_positions = [
            [-0.785, 0.0, 0.0, 0.0, 0.0, 0.0],
            [0.0, -0.785, 0.0, 0.0, 0.0, 0.0],
            [0.0, 0.0, -0.785, 0.0, 0.0, 0.0],
            [0.0, 0.0, 0.0, -0.785, 0.0, 0.0],
            [0.0, 0.0, 0.0, 0.0, -0.785, 0.0],
            [0.0, 0.0, 0.0, 0.0, 0.0, -0.785],
            [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
        ]
        self.current_index = 0
        self.goal = self.target_positions[self.current_index]

        # 각 관절별 PID gains
        self.Kp = np.array([0.5])
        self.Ki = np.array([0.05])
        self.Kd = np.array([0.02])

        # PID 상태
        self.integral = np.zeros(self.num_joints)
        self.prev_error = np.zeros(self.num_joints)
        self.prev_time = self.get_clock().now().nanoseconds / 1e9

        # 퍼블리셔
        self.pub = self.create_publisher(
            Float64MultiArray,
            '/dsr01/gz/dsr_position_controller/commands',
            10
        )

        # 구독자
        self.sub = self.create_subscription(
            JointState,
            '/dsr01/joint_states',
            self.joint_state_callback,
            10
        )

        # 목표 위치를 4초마다 갱신
        self.create_timer(5.0, self.update_goal)

        # 데이터 로그 초기화
        self.time_log = []
        self.position_log = [[] for _ in range(self.num_joints)]
        self.goal_log = [[] for _ in range(self.num_joints)]
        self.error_log = [[] for _ in range(self.num_joints)]

    def update_goal(self):
        self.current_index = (self.current_index + 1) % len(self.target_positions)
        self.goal = self.target_positions[self.current_index]
        self.get_logger().info(f'Updated goal to #{self.current_index + 1}: {self.goal}')

    def joint_state_callback(self, msg: JointState):
        current_pos = np.array(msg.position[:self.num_joints])
        now = self.get_clock().now().nanoseconds / 1e9
        dt = now - self.prev_time
        self.prev_time = now

        error = np.array(self.goal) - current_pos
        self.integral += error * dt
        derivative = (error - self.prev_error) / dt if dt > 0 else 0.0

        control = self.Kp * error + self.Ki * self.integral + self.Kd * derivative
        self.prev_error = error

        # 퍼블리시
        msg_out = Float64MultiArray()
        msg_out.data = control.tolist()
        self.pub.publish(msg_out)

        # 로그 저장
        self.time_log.append(now)
        for i in range(self.num_joints):
            self.position_log[i].append(current_pos[i])
            self.goal_log[i].append(self.goal[i])
            self.error_log[i].append(error[i])

        self.get_logger().info(f'Published control: {np.round(control, 2).tolist()}')

    def save_to_csv(self, filename='joint_log.csv'):
        with open(filename, mode='w', newline='') as file:
            writer = csv.writer(file)
            header = ['time']
            for i in range(self.num_joints):
                header += [f'joint{i+1}_pos', f'joint{i+1}_goal', f'joint{i+1}_error']
            writer.writerow(header)

            for i in range(len(self.time_log)):
                row = [self.time_log[i] - self.time_log[0]]
                for j in range(self.num_joints):
                    row += [
                        self.position_log[j][i],
                        self.goal_log[j][i],
                        self.error_log[j][i]
                    ]
                writer.writerow(row)
        self.get_logger().info(f'Logged joint data to {filename}')

    def plot_graph(self):
        time_array = np.array(self.time_log) - self.time_log[0]

        fig, axs = plt.subplots(3, 2, figsize=(12, 8))
        axs = axs.flatten()

        for j in range(self.num_joints):
            axs[j].plot(time_array, self.position_log[j], label='Position')
            axs[j].plot(time_array, self.goal_log[j], '--', label='Goal')
            axs[j].plot(time_array, self.error_log[j], ':', label='Error')
            axs[j].set_title(f'Joint {j+1}')
            axs[j].set_xlabel('Time [s]')
            axs[j].set_ylabel('Position [rad]')
            axs[j].grid(True)
            axs[j].legend(loc='upper right')

        plt.tight_layout()
        plt.show()


def main(args=None):
    rclpy.init(args=args)
    node = JointPIDController()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info('Node terminated.')
    finally:
        node.save_to_csv()
        node.plot_graph()
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
